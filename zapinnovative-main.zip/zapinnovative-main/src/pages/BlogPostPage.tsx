import { useParams, Link, Navigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Calendar, Clock, ArrowLeft, User } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { AnimatedSection } from "@/hooks/useScrollAnimation";

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  category: string;
  image: string;
}

const blogPosts: BlogPost[] = [
  {
    id: "laptop-overheating-solutions",
    title: "Why Is My Laptop Overheating? Causes and Solutions",
    excerpt: "Is your laptop running hot? Learn the common causes of laptop overheating and effective solutions to keep your device cool and running efficiently.",
    content: `
## Understanding Laptop Overheating

Laptop overheating is one of the most common issues we encounter at our repair shop. When your laptop gets too hot, it can lead to performance throttling, unexpected shutdowns, and even permanent hardware damage.

### Common Causes of Laptop Overheating

**1. Dust Accumulation**
Over time, dust builds up inside your laptop, clogging the vents and fans. This restricts airflow and prevents heat from escaping properly. We recommend cleaning your laptop's internals every 6-12 months.

**2. Dried Thermal Paste**
The thermal paste between your CPU/GPU and heatsink degrades over time. When it dries out, heat transfer becomes inefficient, causing temperatures to rise significantly.

**3. Blocked Air Vents**
Using your laptop on soft surfaces like beds or couches can block the air vents. Always use your laptop on hard, flat surfaces or invest in a laptop cooling pad.

**4. Heavy Workload**
Running demanding applications, games, or multiple programs simultaneously generates more heat than casual browsing.

### Solutions to Fix Overheating

- **Clean the vents and fans** regularly using compressed air
- **Replace thermal paste** every 2-3 years for optimal heat transfer
- **Use a laptop cooling pad** for additional airflow
- **Update your drivers** to ensure efficient hardware operation
- **Limit background processes** to reduce CPU load
- **Consider undervolting** your CPU for lower temperatures

If your laptop continues to overheat after trying these solutions, it may be time for a professional inspection. Our technicians can diagnose and fix overheating issues quickly.
    `,
    author: "Tech Team",
    date: "December 20, 2024",
    readTime: "5 min read",
    category: "Laptop Repair",
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&h=400&fit=crop",
  },
  {
    id: "laptop-slow-performance-fix",
    title: "10 Reasons Your Laptop Is Running Slow and How to Fix It",
    excerpt: "Frustrated with a sluggish laptop? Discover the top reasons behind slow performance and step-by-step solutions to speed up your device.",
    content: `
## Speed Up Your Slow Laptop

A slow laptop can significantly impact your productivity and patience. Before you consider buying a new one, let's explore the common causes and fixes.

### Top 10 Causes of Slow Laptop Performance

**1. Insufficient RAM**
Modern applications require more memory. If you have less than 8GB of RAM, your laptop may struggle with multitasking.

**2. Full Hard Drive**
When your storage is more than 90% full, Windows struggles to manage files efficiently. Aim to keep at least 15-20% free space.

**3. Too Many Startup Programs**
Programs that launch at startup consume resources before you even begin working.

**4. Malware or Viruses**
Malicious software running in the background can severely impact performance.

**5. Outdated Operating System**
Missing updates can lead to compatibility issues and security vulnerabilities that affect performance.

**6. Fragmented Hard Drive (HDD)**
Traditional hard drives become fragmented over time, slowing down file access.

**7. Overheating**
When laptops overheat, they throttle performance to prevent damage.

**8. Outdated Drivers**
Old or corrupted drivers can cause hardware to underperform.

**9. Too Many Browser Tabs**
Each browser tab consumes memory. Chrome is particularly resource-hungry.

**10. Aging Hardware**
Sometimes, older laptops simply cannot keep up with modern software demands.

### Quick Fixes to Speed Up Your Laptop

1. **Upgrade to an SSD** - The single biggest performance improvement
2. **Add more RAM** - 16GB is ideal for most users
3. **Disable startup programs** via Task Manager
4. **Run antivirus scans** regularly
5. **Clear temporary files** using Disk Cleanup
6. **Uninstall unused programs**
7. **Update Windows and drivers**

Need help with any of these upgrades? Our team specializes in laptop performance optimization.
    `,
    author: "Tech Team",
    date: "December 18, 2024",
    readTime: "7 min read",
    category: "Performance",
    image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=400&fit=crop",
  },
  {
    id: "laptop-battery-not-charging",
    title: "Laptop Battery Not Charging? Here's What to Do",
    excerpt: "When your laptop battery refuses to charge, it can be alarming. Learn the troubleshooting steps to diagnose and fix charging issues.",
    content: `
## Troubleshooting Laptop Battery Charging Issues

Nothing is more frustrating than plugging in your laptop only to find it is not charging. Before panicking, try these troubleshooting steps.

### Initial Checks

**1. Verify the Power Source**
- Try a different outlet
- Check if the outlet works with other devices
- Ensure the power strip is turned on

**2. Inspect the Charger**
- Look for frayed cables or bent pins
- Check the adapter brick for damage
- Try a different compatible charger if available

**3. Check the Charging Port**
- Look for debris or dust in the port
- Check for bent or broken pins
- Ensure the plug sits firmly in the port

### Software Solutions

**Reset the Battery Driver**
1. Open Device Manager
2. Expand "Batteries"
3. Right-click "Microsoft ACPI-Compliant Control Method Battery"
4. Select "Uninstall device"
5. Restart your laptop

**Update BIOS**
Outdated BIOS can cause charging issues. Check your manufacturer's website for updates.

**Check Power Settings**
Sometimes Windows power settings can limit charging to preserve battery health.

### Hardware Solutions

**Battery Calibration**
1. Charge to 100%
2. Use until completely drained
3. Leave off for 2-3 hours
4. Charge to 100% without interruption

**Battery Replacement**
If your battery is 2-3 years old and holds little charge, replacement may be necessary. Most laptop batteries last 300-500 charge cycles.

### When to Seek Professional Help

- Swollen or bulging battery (stop using immediately!)
- Burning smell from the laptop
- Charging port is physically damaged
- None of the above solutions work

Our technicians can diagnose charging issues and replace batteries or charging ports quickly and affordably.
    `,
    author: "Tech Team",
    date: "December 15, 2024",
    readTime: "6 min read",
    category: "Battery Issues",
    image: "https://images.unsplash.com/photo-1585776245991-cf89dd7fc73a?w=800&h=400&fit=crop",
  },
  {
    id: "laptop-screen-flickering",
    title: "How to Fix Laptop Screen Flickering: Complete Guide",
    excerpt: "Screen flickering can be caused by software or hardware issues. Learn how to diagnose the problem and find the right solution.",
    content: `
## Fixing Laptop Screen Flickering

Screen flickering is not only annoying but can also cause eye strain and headaches. Let's diagnose and fix this common issue.

### Diagnosing the Cause

**Task Manager Test**
1. Press Ctrl + Shift + Esc to open Task Manager
2. Watch if Task Manager flickers too
3. If it does: Display driver issue
4. If it does not: Incompatible app issue

### Software Fixes

**1. Update Display Drivers**
- Open Device Manager
- Expand "Display adapters"
- Right-click your graphics card
- Select "Update driver"

**2. Roll Back Drivers**
If flickering started after an update:
- Open Device Manager
- Right-click display adapter
- Select Properties > Driver > Roll Back Driver

**3. Adjust Refresh Rate**
- Right-click desktop > Display settings
- Advanced display settings
- Try different refresh rates (60Hz, 75Hz, etc.)

**4. Disable Windows Desktop Manager**
Sometimes WDM can cause flickering. Try disabling hardware acceleration in affected apps.

**5. Uninstall Problematic Apps**
Common culprits include:
- Antivirus software
- iCloud
- Norton
- IDT Audio

### Hardware Fixes

**Check Display Cable**
Loose or damaged display cables inside the laptop can cause flickering. This is common in laptops that have been dropped.

**Replace the Screen**
If the above solutions do not work, the LCD panel itself may be failing. Symptoms include:
- Flickering in specific areas
- Lines appearing on screen
- Flickering that worsens over time

**GPU Issues**
Dedicated graphics cards can cause flickering when failing. This often requires motherboard replacement.

### Prevention Tips

- Keep drivers updated
- Avoid physical impacts to the screen
- Do not open/close the lid forcefully
- Use proper screen cleaning methods

Screen replacement is one of our most common repairs. Contact us for a free diagnosis if your screen continues to flicker.
    `,
    author: "Tech Team",
    date: "December 12, 2024",
    readTime: "5 min read",
    category: "Display Issues",
    image: "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&h=400&fit=crop",
  },
  {
    id: "laptop-keyboard-not-working",
    title: "Laptop Keyboard Not Working? Try These Fixes",
    excerpt: "From stuck keys to complete keyboard failure, we cover all the solutions to get your laptop keyboard working again.",
    content: `
## Fixing Laptop Keyboard Issues

A malfunctioning keyboard can render your laptop nearly useless. Here is how to troubleshoot and fix common keyboard problems.

### Types of Keyboard Issues

1. **Some keys not working**
2. **Entire keyboard unresponsive**
3. **Keys typing wrong characters**
4. **Sticky or stuck keys**
5. **Keyboard typing on its own**

### Quick Fixes to Try First

**Restart Your Laptop**
Sometimes a simple restart resolves temporary glitches.

**Check for Physical Obstructions**
- Turn laptop upside down and gently shake
- Use compressed air between keys
- Look for visible debris

**Disable Filter Keys**
Windows Filter Keys can cause keyboard lag:
- Settings > Accessibility > Keyboard
- Turn off Filter Keys

### Software Solutions

**Update or Reinstall Keyboard Driver**
1. Open Device Manager
2. Expand "Keyboards"
3. Right-click your keyboard
4. Select "Update driver" or "Uninstall device"
5. Restart laptop

**Check Regional Settings**
Wrong language settings can cause incorrect characters:
- Settings > Time & Language > Language
- Ensure correct keyboard layout is selected

**Run Keyboard Troubleshooter**
- Settings > Update & Security > Troubleshoot
- Select "Keyboard" and run troubleshooter

### Hardware Solutions

**Liquid Damage**
If you spilled liquid on your keyboard:
1. Turn off laptop immediately
2. Flip upside down to drain
3. Do not use hair dryer (causes more damage)
4. Let dry for 48-72 hours
5. If still not working, seek professional repair

**Keyboard Replacement**
Most laptop keyboards can be replaced separately from the entire laptop. This is much more affordable than buying a new device.

### Using External Keyboard

As a temporary solution, connect a USB keyboard. This also helps determine if the issue is software or hardware-related.

### Prevention Tips

- Keep food and drinks away from laptop
- Clean keyboard regularly with compressed air
- Use keyboard cover if in dusty environment
- Type gently to avoid key damage

We offer keyboard replacement services for most laptop brands. Bring your laptop in for a free assessment.
    `,
    author: "Tech Team",
    date: "December 10, 2024",
    readTime: "6 min read",
    category: "Keyboard Issues",
    image: "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=800&h=400&fit=crop",
  },
  {
    id: "laptop-wont-turn-on",
    title: "Laptop Will Not Turn On? Step-by-Step Troubleshooting",
    excerpt: "When your laptop refuses to power on, do not panic. Follow this comprehensive guide to diagnose and potentially fix the issue yourself.",
    content: `
## What to Do When Your Laptop Will Not Turn On

A laptop that will not power on is scary, but it does not always mean disaster. Follow these steps to diagnose the problem.

### Step 1: Check the Basics

**Power Source**
- Is the laptop plugged in?
- Is the outlet working?
- Are there any lights on the charger?

**Battery Check**
- Remove the battery (if removable)
- Try powering on with just the charger
- Try a different compatible charger

**External Devices**
- Disconnect all USB devices
- Remove external monitors
- Take out any memory cards

### Step 2: Perform a Hard Reset

1. Disconnect the charger
2. Remove the battery (if possible)
3. Hold power button for 30 seconds
4. Reconnect battery and charger
5. Try turning on

### Step 3: Check for Signs of Life

**No lights, no sounds**
- Could be dead battery, faulty charger, or motherboard issue

**Lights but no display**
- Try connecting to external monitor
- Could be screen or graphics issue

**Fans spin then stop**
- Possible RAM or CPU issue
- Try reseating RAM if accessible

**Beeping sounds**
- These are diagnostic codes
- Count the beeps and search for your laptop model's beep codes

### Step 4: Advanced Troubleshooting

**CMOS Reset**
Remove the CMOS battery for 5 minutes to reset BIOS settings.

**RAM Reseat**
1. Open the back panel
2. Remove RAM sticks
3. Clean contacts with eraser
4. Reseat firmly

**Check for Swollen Battery**
A swollen battery can prevent power-on. Look for:
- Trackpad not sitting flat
- Bottom panel bulging
- Gaps in the case

### When to Seek Professional Help

- Burning smell or smoke
- Visible damage to motherboard
- Water damage
- Hard reset does not work

### Common Causes We Fix

- Failed power jack
- Dead motherboard
- Faulty RAM
- Corrupted BIOS
- Short circuits

Do not attempt to open your laptop if you are not comfortable with electronics. Our technicians can diagnose power issues quickly and provide affordable repair options.
    `,
    author: "Tech Team",
    date: "December 8, 2024",
    readTime: "7 min read",
    category: "Power Issues",
    image: "https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=800&h=400&fit=crop",
  },
];

const BlogPostPage = () => {
  const { slug } = useParams();
  const post = blogPosts.find(p => p.id === slug);

  if (!post) {
    return <Navigate to="/blog" replace />;
  }

  // Simple markdown-like rendering
  const renderContent = (content: string) => {
    const lines = content.trim().split('\n');
    const elements: JSX.Element[] = [];
    let listItems: string[] = [];
    let listType: 'ul' | 'ol' | null = null;

    const flushList = () => {
      if (listItems.length > 0 && listType) {
        const ListTag = listType;
        elements.push(
          <ListTag key={elements.length} className={`${listType === 'ul' ? 'list-disc' : 'list-decimal'} list-inside space-y-2 my-4 text-muted-foreground`}>
            {listItems.map((item, i) => <li key={i}>{item}</li>)}
          </ListTag>
        );
        listItems = [];
        listType = null;
      }
    };

    lines.forEach((line, index) => {
      const trimmedLine = line.trim();

      if (trimmedLine.startsWith('## ')) {
        flushList();
        elements.push(
          <h2 key={index} className="font-display text-2xl font-bold mt-8 mb-4 text-foreground">
            {trimmedLine.replace('## ', '')}
          </h2>
        );
      } else if (trimmedLine.startsWith('### ')) {
        flushList();
        elements.push(
          <h3 key={index} className="font-display text-xl font-semibold mt-6 mb-3 text-foreground">
            {trimmedLine.replace('### ', '')}
          </h3>
        );
      } else if (trimmedLine.startsWith('**') && trimmedLine.endsWith('**')) {
        flushList();
        elements.push(
          <p key={index} className="font-semibold mt-4 mb-2 text-foreground">
            {trimmedLine.replace(/\*\*/g, '')}
          </p>
        );
      } else if (trimmedLine.startsWith('- ')) {
        if (listType !== 'ul') {
          flushList();
          listType = 'ul';
        }
        listItems.push(trimmedLine.replace('- ', '').replace(/\*\*/g, ''));
      } else if (/^\d+\. /.test(trimmedLine)) {
        if (listType !== 'ol') {
          flushList();
          listType = 'ol';
        }
        listItems.push(trimmedLine.replace(/^\d+\. /, '').replace(/\*\*/g, ''));
      } else if (trimmedLine) {
        flushList();
        elements.push(
          <p key={index} className="text-muted-foreground leading-relaxed my-3">
            {trimmedLine.replace(/\*\*/g, '')}
          </p>
        );
      }
    });

    flushList();
    return elements;
  };

  return (
    <>
      <Helmet>
        <title>{post.title} | Zapinnovative Blog</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>

      <Navbar />

      <main className="pt-20">
        {/* Hero Section */}
        <section className="relative">
          <div className="aspect-[21/9] lg:aspect-[3/1] overflow-hidden">
            <img 
              src={post.image} 
              alt={post.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          </div>
          
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto -mt-32 relative z-10">
              <AnimatedSection>
                <Link 
                  to="/blog"
                  className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-6"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to Blog
                </Link>
                
                <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                  {post.category}
                </span>
                
                <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
                  {post.title}
                </h1>
                
                <div className="flex flex-wrap items-center gap-4 text-muted-foreground">
                  <span className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    {post.author}
                  </span>
                  <span className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {post.date}
                  </span>
                  <span className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    {post.readTime}
                  </span>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        {/* Content */}
        <section className="py-12 lg:py-16">
          <div className="container mx-auto px-4">
            <AnimatedSection className="max-w-4xl mx-auto">
              <div className="prose prose-lg max-w-none">
                {renderContent(post.content)}
              </div>
            </AnimatedSection>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4">
            <AnimatedSection className="text-center max-w-2xl mx-auto">
              <h2 className="font-display text-2xl sm:text-3xl font-bold mb-4">
                Still Having Issues?
              </h2>
              <p className="text-muted-foreground mb-8">
                Our expert technicians are ready to help diagnose and fix your laptop problems.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link 
                  to="/#contact"
                  className="inline-flex items-center justify-center px-8 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
                >
                  Contact Us
                </Link>
                <Link 
                  to="/blog"
                  className="inline-flex items-center justify-center px-8 py-3 rounded-lg border border-border text-foreground font-medium hover:bg-muted transition-colors"
                >
                  More Articles
                </Link>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default BlogPostPage;
