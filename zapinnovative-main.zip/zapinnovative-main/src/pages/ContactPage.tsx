import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ContactSection from "@/components/ContactSection";

const ContactPage = () => {
  return (
    <>
      <Helmet>
        <title>Contact Us - Get a Free Quote | ZAP Computer Repair</title>
        <meta name="description" content="Get a free quote for your repair needs. Contact Zapinnovative via phone, email, or fill out our contact form." />
      </Helmet>
      
      <Navbar />
      
      <main className="min-h-screen bg-background pt-20">
        <ContactSection />
      </main>
      
      <Footer />
    </>
  );
};

export default ContactPage;
