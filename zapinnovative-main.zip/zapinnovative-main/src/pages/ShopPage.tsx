import { useState, useMemo } from "react";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useCart } from "@/contexts/CartContext";
import { ShoppingCart, Star, Cpu, HardDrive, Monitor, Keyboard, Mouse, Headphones, Battery, Cable, RotateCcw, Shield, Clock, CheckCircle, Search, X } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Laptop RAM 8GB DDR4",
    description: "High-performance DDR4 RAM module for laptops. Compatible with most brands.",
    price: 2499,
    originalPrice: 2999,
    image: "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=400&h=300&fit=crop",
    category: "Memory",
    rating: 4.5,
    inStock: true,
    icon: Cpu
  },
  {
    id: 2,
    name: "SSD 256GB SATA",
    description: "Fast and reliable solid-state drive for quick boot times and file access.",
    price: 1999,
    originalPrice: 2499,
    image: "https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?w=400&h=300&fit=crop",
    category: "Storage",
    rating: 4.8,
    inStock: true,
    icon: HardDrive
  },
  {
    id: 3,
    name: "Laptop Charger Universal",
    description: "65W universal laptop charger with multiple connector tips.",
    price: 899,
    originalPrice: 1199,
    image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=400&h=300&fit=crop",
    category: "Accessories",
    rating: 4.3,
    inStock: true,
    icon: Battery
  },
  {
    id: 4,
    name: "USB-C Hub 7-in-1",
    description: "Multi-port USB-C hub with HDMI, USB 3.0, SD card reader.",
    price: 1299,
    originalPrice: 1599,
    image: "https://images.unsplash.com/photo-1625723044792-44de16ccb4e9?w=400&h=300&fit=crop",
    category: "Accessories",
    rating: 4.6,
    inStock: true,
    icon: Cable
  },
  {
    id: 5,
    name: "Wireless Mouse",
    description: "Ergonomic wireless mouse with adjustable DPI and long battery life.",
    price: 599,
    originalPrice: 799,
    image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&h=300&fit=crop",
    category: "Peripherals",
    rating: 4.4,
    inStock: true,
    icon: Mouse
  },
  {
    id: 6,
    name: "Mechanical Keyboard",
    description: "RGB backlit mechanical keyboard with blue switches.",
    price: 2999,
    originalPrice: 3499,
    image: "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=400&h=300&fit=crop",
    category: "Peripherals",
    rating: 4.7,
    inStock: true,
    icon: Keyboard
  },
  {
    id: 7,
    name: "Monitor Stand",
    description: "Adjustable monitor stand with cable management.",
    price: 1499,
    originalPrice: 1799,
    image: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=400&h=300&fit=crop",
    category: "Accessories",
    rating: 4.2,
    inStock: false,
    icon: Monitor
  },
  {
    id: 8,
    name: "USB Headset",
    description: "Noise-cancelling USB headset with microphone for calls and gaming.",
    price: 1799,
    originalPrice: 2199,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=300&fit=crop",
    category: "Peripherals",
    rating: 4.5,
    inStock: true,
    icon: Headphones
  }
];

const categories = ["All", "Memory", "Storage", "Accessories", "Peripherals"];
const MIN_PRICE = 0;
const MAX_PRICE = 5000;

const ShopPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [priceRange, setPriceRange] = useState<[number, number]>([MIN_PRICE, MAX_PRICE]);
  const { addItem } = useCart();

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Search filter
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Category filter
      const matchesCategory = selectedCategory === "All" || product.category === selectedCategory;
      
      // Price filter
      const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1];
      
      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [searchQuery, selectedCategory, priceRange]);

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedCategory("All");
    setPriceRange([MIN_PRICE, MAX_PRICE]);
  };

  const hasActiveFilters = searchQuery !== "" || selectedCategory !== "All" || priceRange[0] !== MIN_PRICE || priceRange[1] !== MAX_PRICE;

  return (
    <>
      <Helmet>
        <title>Shop - Computer Parts & Accessories | ZAP Computer Repair</title>
        <meta name="description" content="Shop quality computer parts, accessories, and peripherals. RAM, SSD, chargers, keyboards, and more at competitive prices." />
      </Helmet>
      
      <Navbar />
      
      <main className="min-h-screen bg-background pt-20">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary/10 to-primary/5 py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Computer Parts & Accessories
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Quality parts and accessories for your computer needs. All products come with warranty and expert support.
            </p>
          </div>
        </section>

        {/* Search & Filters */}
        <section className="py-8 border-b border-border">
          <div className="container mx-auto px-4">
            {/* Search Bar */}
            <div className="max-w-xl mx-auto mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-10"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap justify-center gap-3 mb-6">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  className="rounded-full"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>

            {/* Price Range Filter */}
            <div className="max-w-md mx-auto">
              <Label className="text-sm font-medium text-foreground mb-3 block text-center">
                Price Range: ₹{priceRange[0]} - ₹{priceRange[1]}
              </Label>
              <Slider
                value={priceRange}
                onValueChange={(value) => setPriceRange(value as [number, number])}
                min={MIN_PRICE}
                max={MAX_PRICE}
                step={100}
                className="w-full"
              />
            </div>

            {/* Clear Filters & Results Count */}
            <div className="flex items-center justify-center gap-4 mt-6">
              <p className="text-sm text-muted-foreground">
                Showing {filteredProducts.length} of {products.length} products
              </p>
              {hasActiveFilters && (
                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-primary">
                  <X className="w-4 h-4 mr-1" />
                  Clear Filters
                </Button>
              )}
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <p className="text-lg text-muted-foreground mb-4">No products found matching your criteria.</p>
                  <Button variant="outline" onClick={clearFilters}>
                    Clear Filters
                  </Button>
                </div>
              ) : (
                filteredProducts.map((product) => {
                  const IconComponent = product.icon;
                  return (
                    <Card key={product.id} className="group overflow-hidden hover:shadow-lg transition-shadow duration-300">
                      <CardHeader className="p-0 relative">
                        <div className="aspect-square overflow-hidden bg-muted">
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                        {!product.inStock && (
                          <Badge variant="destructive" className="absolute top-3 right-3">
                            Out of Stock
                          </Badge>
                        )}
                        {product.inStock && product.originalPrice > product.price && (
                          <Badge className="absolute top-3 left-3 bg-primary">
                            Sale
                          </Badge>
                        )}
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <IconComponent className="w-4 h-4 text-primary" />
                          <span className="text-xs text-muted-foreground">{product.category}</span>
                        </div>
                        <h3 className="font-semibold text-foreground mb-1 line-clamp-1">
                          {product.name}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                          {product.description}
                        </p>
                        <div className="flex items-center gap-1 mb-2">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < Math.floor(product.rating)
                                  ? "text-yellow-500 fill-yellow-500"
                                  : "text-muted"
                              }`}
                            />
                          ))}
                          <span className="text-sm text-muted-foreground ml-1">
                            ({product.rating})
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xl font-bold text-primary">
                            ₹{product.price}
                          </span>
                          {product.originalPrice > product.price && (
                            <span className="text-sm text-muted-foreground line-through">
                              ₹{product.originalPrice}
                            </span>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter className="p-4 pt-0">
                        <Button
                          className="w-full gap-2"
                          disabled={!product.inStock}
                          onClick={() => addItem({
                            id: product.id,
                            name: product.name,
                            price: product.price,
                            image: product.image,
                          })}
                        >
                          <ShoppingCart className="w-4 h-4" />
                          {product.inStock ? "Add to Cart" : "Out of Stock"}
                        </Button>
                      </CardFooter>
                    </Card>
                  );
                })
              )}
            </div>
          </div>
        </section>

        {/* Info Section */}
        <section className="py-12 bg-muted/50">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ShoppingCart className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Free Delivery</h3>
                <p className="text-sm text-muted-foreground">On orders above ₹999</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Quality Assured</h3>
                <p className="text-sm text-muted-foreground">All products tested & verified</p>
              </div>
              <div>
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Cpu className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Expert Support</h3>
                <p className="text-sm text-muted-foreground">Technical help available</p>
              </div>
            </div>
          </div>
        </section>

        {/* Return Policy Section */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Return Policy
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                We want you to be completely satisfied with your purchase. Here's our hassle-free return policy.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <Card className="text-center p-6">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">7-Day Returns</h3>
                <p className="text-sm text-muted-foreground">
                  Return any product within 7 days of delivery for a full refund
                </p>
              </Card>
              
              <Card className="text-center p-6">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <RotateCcw className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Easy Exchange</h3>
                <p className="text-sm text-muted-foreground">
                  Exchange defective products for free within 15 days
                </p>
              </Card>
              
              <Card className="text-center p-6">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Warranty Covered</h3>
                <p className="text-sm text-muted-foreground">
                  All products come with manufacturer warranty
                </p>
              </Card>
              
              <Card className="text-center p-6">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">No Questions Asked</h3>
                <p className="text-sm text-muted-foreground">
                  Hassle-free returns with no complicated process
                </p>
              </Card>
            </div>

            <div className="bg-muted/50 rounded-lg p-8">
              <h3 className="text-xl font-semibold text-foreground mb-6">Return Policy Details</h3>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-medium text-foreground mb-3">Eligible for Return:</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      Products in original packaging with all accessories
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      Unused and undamaged items
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      Products with manufacturing defects
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      Wrong product delivered
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-foreground mb-3">How to Return:</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <span className="w-5 h-5 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs flex-shrink-0">1</span>
                      Contact our support team via phone or email
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-5 h-5 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs flex-shrink-0">2</span>
                      Get return authorization and shipping label
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-5 h-5 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs flex-shrink-0">3</span>
                      Pack the product securely and ship it back
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-5 h-5 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs flex-shrink-0">4</span>
                      Refund processed within 5-7 business days
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
};

export default ShopPage;
