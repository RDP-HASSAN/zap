import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import TestimonialsSection from "@/components/TestimonialsSection";

const TestimonialsPage = () => {
  return (
    <>
      <Helmet>
        <title>Customer Testimonials - ZAP Computer Repair</title>
        <meta name="description" content="Read what our customers say about our repair services. Thousands of happy customers trust Zapinnovative with their devices." />
      </Helmet>
      
      <Navbar />
      
      <main className="min-h-screen bg-background pt-20">
        <TestimonialsSection />
      </main>
      
      <Footer />
    </>
  );
};

export default TestimonialsPage;
