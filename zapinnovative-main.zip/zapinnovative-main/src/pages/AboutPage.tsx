import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AboutSection from "@/components/AboutSection";

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About Us - ZAP Computer Repair | Quality Repairs, Fair Prices</title>
        <meta name="description" content="Learn why thousands of customers trust Zapinnovative for their computer, laptop, and printer repairs. Certified technicians, 2-year warranty, and transparent pricing." />
      </Helmet>
      
      <Navbar />
      
      <main className="min-h-screen bg-background pt-20">
        <AboutSection />
      </main>
      
      <Footer />
    </>
  );
};

export default AboutPage;
