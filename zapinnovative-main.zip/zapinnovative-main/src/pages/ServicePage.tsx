import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { ArrowLeft, ArrowRight, Check, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getServiceBySlug, servicesData } from "@/data/servicesData";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AnimatedServiceIcon from "@/components/AnimatedServiceIcon";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const ServicePage = () => {
  const { slug } = useParams<{ slug: string }>();
  const service = getServiceBySlug(slug || "");

  if (!service) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Service Not Found</h1>
          <Link to="/">
            <Button variant="hero">Go Back Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const ServiceIcon = service.icon;

  return (
    <>
      <Helmet>
        <title>{service.title} | Zapinnovative IT Repair Services</title>
        <meta name="description" content={service.heroDescription} />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />

        {/* Hero Section */}
        <section className="relative pt-32 pb-20 overflow-hidden">
          <div className="absolute inset-0 hero-gradient" />
          <div className="absolute top-1/3 left-1/4 w-72 h-72 bg-primary/20 rounded-full blur-[100px]" />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-accent/20 rounded-full blur-[80px]" />
          
          <div className="container mx-auto px-4 relative z-10">
            <Link 
              to="/#services" 
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to All Services
            </Link>

            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="max-w-xl animate-fade-up">
                <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mb-8 glow-primary">
                  <ServiceIcon className="w-10 h-10 text-primary" />
                </div>
                
                <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
                  {service.title}
                </h1>
                
                <p className="text-xl text-muted-foreground max-w-3xl mb-8">
                  {service.heroDescription}
                </p>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button variant="hero" size="xl">
                    Get Free Quote
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                  <Button variant="heroOutline" size="xl">
                    Call: +91 98765 43210
                  </Button>
                </div>
              </div>

              {/* Animated Service Illustration */}
              <div className="hidden lg:block animate-fade-in" style={{ animationDelay: '0.3s' }}>
                <AnimatedServiceIcon slug={slug || ""} />
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="font-display text-3xl sm:text-4xl font-bold mb-12 text-center">
              What We <span className="gradient-text">Fix & Service</span>
            </h2>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
              {service.features.map((feature, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-3 p-4 rounded-xl card-gradient border border-border/50"
                >
                  <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-foreground">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-20 relative">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
          
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="text-primary font-medium text-sm uppercase tracking-wider">
                Transparent Pricing
              </span>
              <h2 className="font-display text-3xl sm:text-4xl font-bold mt-4">
                {service.title} <span className="gradient-text">Pricing</span>
              </h2>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                No hidden charges. Get a free diagnostic and exact quote before any work begins.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
              {service.pricing.map((item, index) => (
                <div 
                  key={index}
                  className={`p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1 ${
                    index === 0 
                      ? 'bg-primary/10 border-primary/30' 
                      : 'card-gradient border-border/50 hover:border-primary/30'
                  }`}
                >
                  <h3 className="font-display text-lg font-semibold mb-2">
                    {item.service}
                  </h3>
                  <div className="text-2xl font-bold text-primary mb-3">
                    {item.price}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>

            <p className="text-center text-muted-foreground mt-8 text-sm">
              * Prices may vary based on specific model and damage extent. Final quote provided after free diagnostic.
            </p>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="font-display text-3xl sm:text-4xl font-bold">
                Frequently Asked <span className="gradient-text">Questions</span>
              </h2>
            </div>

            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible className="space-y-4">
                {service.faqs.map((faq, index) => (
                  <AccordionItem 
                    key={index} 
                    value={`faq-${index}`}
                    className="card-gradient border border-border/50 rounded-xl px-6 overflow-hidden"
                  >
                    <AccordionTrigger className="text-left font-semibold hover:text-primary transition-colors py-5">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground pb-5">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 relative">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center p-12 rounded-3xl card-gradient border border-primary/20">
              <h2 className="font-display text-3xl sm:text-4xl font-bold mb-6">
                Need {service.title}?
              </h2>
              <p className="text-muted-foreground text-lg mb-8">
                Bring your device for a free diagnostic. We'll give you an exact quote 
                before starting any work. No fix, no fee!
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button variant="gradient" size="xl">
                  Get Free Diagnostic
                  <ArrowRight className="w-5 h-5" />
                </Button>
                <Button variant="heroOutline" size="xl">
                  WhatsApp Us
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Other Services */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="font-display text-2xl sm:text-3xl font-bold mb-8 text-center">
              Other Services
            </h2>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 max-w-5xl mx-auto">
              {servicesData
                .filter(s => s.slug !== service.slug)
                .map((otherService) => {
                  const OtherIcon = otherService.icon;
                  return (
                    <Link
                      key={otherService.slug}
                      to={`/services/${otherService.slug}`}
                      className="flex items-center gap-3 p-4 rounded-xl card-gradient border border-border/50 hover:border-primary/50 transition-all duration-300 group"
                    >
                      <OtherIcon className="w-5 h-5 text-primary" />
                      <span className="font-medium group-hover:text-primary transition-colors">
                        {otherService.title}
                      </span>
                    </Link>
                  );
                })}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default ServicePage;
