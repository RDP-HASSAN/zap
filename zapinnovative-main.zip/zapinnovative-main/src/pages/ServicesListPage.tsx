import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Check, ArrowRight, Phone } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { AnimatedSection } from "@/hooks/useScrollAnimation";
import { servicesData } from "@/data/servicesData";
import { Button } from "@/components/ui/button";

const ServicesListPage = () => {
  return (
    <>
      <Helmet>
        <title>Our Repair Services & Pricing | Zapinnovative</title>
        <meta name="description" content="Complete list of repair services with transparent pricing. Laptop repair, computer repair, printer service, data recovery, network setup, and hardware upgrades." />
      </Helmet>

      <Navbar />

      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 lg:py-24 hero-gradient relative overflow-hidden">
          <div className="absolute inset-0 opacity-30">
            <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-[100px]" />
            <div className="absolute bottom-10 right-10 w-96 h-96 bg-accent/20 rounded-full blur-[120px]" />
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <AnimatedSection className="text-center max-w-3xl mx-auto">
              <span className="text-primary font-medium text-sm uppercase tracking-wider">
                Our Services
              </span>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold mt-4 mb-6">
                Repair Services <span className="gradient-text">& Pricing</span>
              </h1>
              <p className="text-muted-foreground text-lg lg:text-xl">
                Transparent pricing with no hidden fees. Free diagnostics on all repairs. 
                Quality parts and expert technicians you can trust.
              </p>
            </AnimatedSection>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4">
            <div className="space-y-16 lg:space-y-24">
              {servicesData.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <AnimatedSection 
                    key={service.slug}
                    className={`grid lg:grid-cols-2 gap-8 lg:gap-16 items-start ${
                      index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                    }`}
                  >
                    {/* Service Info */}
                    <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                      <div className="flex items-center gap-4 mb-6">
                        <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                          <IconComponent className="w-7 h-7 text-primary" />
                        </div>
                        <h2 className="font-display text-3xl font-bold">{service.title}</h2>
                      </div>
                      
                      <p className="text-muted-foreground text-lg mb-6">
                        {service.heroDescription}
                      </p>

                      <h3 className="font-display text-lg font-semibold mb-4">What We Offer</h3>
                      <ul className="grid sm:grid-cols-2 gap-3 mb-8">
                        {service.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                            <span className="text-muted-foreground text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>

                      <Link 
                        to={`/services/${service.slug}`}
                        className="inline-flex items-center gap-2 text-primary font-medium hover:gap-3 transition-all"
                      >
                        View Full Details <ArrowRight className="w-4 h-4" />
                      </Link>
                    </div>

                    {/* Pricing Table */}
                    <div className={`rounded-2xl card-gradient border border-border/50 overflow-hidden ${
                      index % 2 === 1 ? 'lg:order-1' : ''
                    }`}>
                      <div className="bg-primary/10 px-6 py-4 border-b border-border/50">
                        <h3 className="font-display text-xl font-semibold">Pricing</h3>
                        <p className="text-sm text-muted-foreground">All prices are indicative. Final quote after diagnosis.</p>
                      </div>
                      <div className="divide-y divide-border/50">
                        {service.pricing.map((item, idx) => (
                          <div key={idx} className="px-6 py-4 hover:bg-muted/30 transition-colors">
                            <div className="flex justify-between items-start mb-1">
                              <span className="font-medium">{item.service}</span>
                              <span className="font-display font-bold text-primary whitespace-nowrap ml-4">
                                {item.price}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </AnimatedSection>
                );
              })}
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-16 lg:py-24 bg-card">
          <div className="container mx-auto px-4">
            <AnimatedSection className="text-center max-w-2xl mx-auto mb-12">
              <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4">
                Why Choose Us?
              </h2>
              <p className="text-muted-foreground">
                We stand behind our work with quality service and customer satisfaction.
              </p>
            </AnimatedSection>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: "Free Diagnostics", desc: "No charge for assessing your device issues" },
                { title: "90-Day Warranty", desc: "All repairs covered for 90 days" },
                { title: "Genuine Parts", desc: "Original or high-quality compatible parts" },
                { title: "Quick Turnaround", desc: "Most repairs completed same day" },
              ].map((item, idx) => (
                <AnimatedSection key={idx} delay={idx * 100}>
                  <div className="text-center p-6 rounded-2xl bg-background border border-border/50">
                    <h3 className="font-display font-semibold mb-2">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4">
            <AnimatedSection className="text-center max-w-2xl mx-auto">
              <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4">
                Ready to Get Your Device Fixed?
              </h2>
              <p className="text-muted-foreground mb-8">
                Contact us today for a free diagnosis. No appointment needed for walk-ins.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="hero" size="lg" asChild>
                  <Link to="/#contact">
                    Get Free Quote
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <a href="tel:+919718024792" className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Call Now
                  </a>
                </Button>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ServicesListPage;
