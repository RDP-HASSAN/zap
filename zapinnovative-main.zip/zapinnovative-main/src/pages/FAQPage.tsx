import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FAQSection from "@/components/FAQSection";

const FAQPage = () => {
  return (
    <>
      <Helmet>
        <title>FAQ - Frequently Asked Questions | ZAP Computer Repair</title>
        <meta name="description" content="Find answers to common questions about our repair services, warranty, pricing, and more." />
      </Helmet>
      
      <Navbar />
      
      <main className="min-h-screen bg-background pt-20">
        <FAQSection />
      </main>
      
      <Footer />
    </>
  );
};

export default FAQPage;
