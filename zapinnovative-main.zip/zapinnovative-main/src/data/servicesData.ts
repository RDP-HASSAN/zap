import { 
  Laptop, 
  Monitor, 
  Printer, 
  HardDrive, 
  Wifi, 
  Wrench,
  Cloud,
  Shield,
  Code,
  BarChart3,
  Bot,
  LucideIcon
} from "lucide-react";

export interface ServiceData {
  slug: string;
  icon: LucideIcon;
  title: string;
  shortDescription: string;
  heroDescription: string;
  features: string[];
  pricing: {
    service: string;
    price: string;
    description: string;
  }[];
  faqs: {
    question: string;
    answer: string;
  }[];
}

export const servicesData: ServiceData[] = [
  {
    slug: "laptop-repair",
    icon: Laptop,
    title: "Laptop Repair",
    shortDescription: "Screen replacement, keyboard repair, battery issues, overheating fixes, and complete diagnostics for all laptop brands.",
    heroDescription: "Expert laptop repair services for all brands including Dell, HP, Lenovo, ASUS, Acer, Apple MacBook, and more. We fix everything from cracked screens to motherboard issues.",
    features: [
      "Screen replacement for all laptop sizes",
      "Keyboard and trackpad repair",
      "Battery replacement and calibration",
      "Overheating and fan issues",
      "Charging port repair",
      "Motherboard diagnostics and repair",
      "Hinge and body repair",
      "Virus and malware removal"
    ],
    pricing: [
      { service: "Free Diagnostic", price: "₹0", description: "Complete assessment of your laptop's issues" },
      { service: "Screen Replacement", price: "₹2,500 - ₹8,000", description: "Depends on screen size and type (LCD/LED/OLED)" },
      { service: "Keyboard Replacement", price: "₹1,500 - ₹4,000", description: "Original or compatible keyboard options" },
      { service: "Battery Replacement", price: "₹2,000 - ₹5,000", description: "Genuine or high-quality compatible batteries" },
      { service: "Charging Port Repair", price: "₹800 - ₹2,000", description: "DC jack replacement or soldering" },
      { service: "Virus Removal", price: "₹500 - ₹1,500", description: "Complete malware cleanup and protection setup" },
    ],
    faqs: [
      { question: "How long does a laptop screen replacement take?", answer: "Most screen replacements are completed within 2-4 hours. For rare screen models, it may take 1-2 days if we need to order the part." },
      { question: "Do you repair all laptop brands?", answer: "Yes! We repair all major brands including Dell, HP, Lenovo, ASUS, Acer, Apple MacBook, MSI, Samsung, and more." },
      { question: "Is my data safe during repair?", answer: "Absolutely. We never access your personal data. For extra security, we recommend backing up before bringing your laptop." },
    ]
  },
  {
    slug: "computer-repair",
    icon: Monitor,
    title: "Computer Repair",
    shortDescription: "Desktop troubleshooting, hardware upgrades, virus removal, OS installation, and performance optimization.",
    heroDescription: "Professional desktop computer repair and upgrade services. Whether it's a slow PC, blue screen errors, or hardware failures, our technicians can diagnose and fix any issue.",
    features: [
      "Hardware diagnostics and troubleshooting",
      "Operating system installation (Windows/Linux)",
      "Virus, malware, and ransomware removal",
      "RAM and storage upgrades",
      "Graphics card installation",
      "Power supply replacement",
      "CPU and cooling system repair",
      "BIOS and firmware updates"
    ],
    pricing: [
      { service: "Free Diagnostic", price: "₹0", description: "Complete hardware and software assessment" },
      { service: "OS Installation", price: "₹800 - ₹1,500", description: "Windows 10/11 or Linux installation with drivers" },
      { service: "Virus Removal", price: "₹500 - ₹1,500", description: "Complete system cleanup and security setup" },
      { service: "RAM Upgrade", price: "₹500 + RAM cost", description: "Installation and compatibility check included" },
      { service: "SSD Upgrade", price: "₹500 + SSD cost", description: "Includes data migration from old drive" },
      { service: "Power Supply Replacement", price: "₹500 + PSU cost", description: "Quality PSU with proper wattage" },
    ],
    faqs: [
      { question: "Can you speed up my slow computer?", answer: "Yes! We can diagnose why your computer is slow and recommend solutions like RAM upgrades, SSD installation, or software optimization." },
      { question: "Do you build custom PCs?", answer: "Absolutely! We offer custom PC building services for gaming, workstations, or general use. Contact us with your requirements." },
      { question: "Can you recover data from a dead computer?", answer: "In most cases, yes. Even if the computer won't turn on, we can often recover data from the hard drive or SSD." },
    ]
  },
  {
    slug: "printer-repair",
    icon: Printer,
    title: "Printer Repair",
    shortDescription: "Printer maintenance, cartridge issues, paper jams, connectivity problems, and driver installation services.",
    heroDescription: "Complete printer repair and maintenance services for inkjet, laser, and all-in-one printers. We service HP, Canon, Epson, Brother, Samsung, and all major brands.",
    features: [
      "Paper jam troubleshooting and prevention",
      "Print head cleaning and replacement",
      "Cartridge and toner issues",
      "Connectivity setup (WiFi, USB, Network)",
      "Driver installation and updates",
      "Print quality optimization",
      "Roller and feeder repair",
      "Regular maintenance service"
    ],
    pricing: [
      { service: "Free Diagnostic", price: "₹0", description: "Assessment of printer issues" },
      { service: "Basic Service", price: "₹500 - ₹1,000", description: "Cleaning, alignment, and basic fixes" },
      { service: "Print Head Cleaning", price: "₹800 - ₹2,000", description: "Deep cleaning for inkjet printers" },
      { service: "Roller Replacement", price: "₹1,000 - ₹2,500", description: "For paper feeding issues" },
      { service: "Network Setup", price: "₹500 - ₹1,000", description: "WiFi or network printer configuration" },
      { service: "Annual Maintenance", price: "₹2,000 - ₹5,000", description: "Quarterly service visits included" },
    ],
    faqs: [
      { question: "Why does my printer keep jamming?", answer: "Paper jams can be caused by worn rollers, incorrect paper size, or debris inside. We'll diagnose and fix the root cause." },
      { question: "Can you refill ink cartridges?", answer: "We offer cartridge refilling for compatible models. However, for best results, we often recommend compatible new cartridges." },
      { question: "Do you offer on-site printer repair?", answer: "Yes! For offices with multiple printers, we offer on-site repair and maintenance services." },
    ]
  },
  {
    slug: "data-recovery",
    icon: HardDrive,
    title: "Data Recovery",
    shortDescription: "Recover lost files from damaged hard drives, SSDs, USB drives, and memory cards with high success rates.",
    heroDescription: "Professional data recovery services for accidentally deleted files, formatted drives, corrupted storage, and physically damaged devices. We recover what others can't.",
    features: [
      "Hard drive data recovery",
      "SSD data recovery",
      "USB flash drive recovery",
      "Memory card recovery (SD, microSD)",
      "RAID array recovery",
      "Deleted file recovery",
      "Formatted drive recovery",
      "Water/fire damaged device recovery"
    ],
    pricing: [
      { service: "Free Diagnostic", price: "₹0", description: "Assessment and recovery possibility evaluation" },
      { service: "Deleted File Recovery", price: "₹1,500 - ₹3,000", description: "For accidentally deleted files" },
      { service: "Logical Recovery", price: "₹2,500 - ₹5,000", description: "Corrupted or formatted drives" },
      { service: "Physical Recovery", price: "₹5,000 - ₹15,000", description: "Damaged drives requiring cleanroom" },
      { service: "USB/Memory Card", price: "₹1,000 - ₹3,000", description: "Flash storage recovery" },
      { service: "RAID Recovery", price: "₹10,000+", description: "Server and NAS data recovery" },
    ],
    faqs: [
      { question: "Can you recover data from a clicking hard drive?", answer: "Clicking usually indicates mechanical failure. We have cleanroom facilities for such recoveries with good success rates." },
      { question: "How long does data recovery take?", answer: "Simple recoveries take 1-2 days. Complex physical recoveries may take 5-10 days depending on damage severity." },
      { question: "Is my data kept confidential?", answer: "Absolutely. We sign NDAs for business data and never access personal files. Your privacy is our priority." },
    ]
  },
  {
    slug: "network-setup",
    icon: Wifi,
    title: "Network Setup",
    shortDescription: "Home and office network installation, WiFi troubleshooting, router configuration, and security setup.",
    heroDescription: "Professional network installation and troubleshooting for homes and offices. From WiFi dead zones to complete office networking, we ensure fast and secure connectivity.",
    features: [
      "WiFi network installation",
      "Router and modem setup",
      "Network security configuration",
      "WiFi range extension",
      "Mesh network installation",
      "Office network cabling",
      "Network troubleshooting",
      "VPN setup for remote work"
    ],
    pricing: [
      { service: "Free Consultation", price: "₹0", description: "Network assessment and recommendations" },
      { service: "Home WiFi Setup", price: "₹500 - ₹1,500", description: "Router configuration and optimization" },
      { service: "WiFi Extender Setup", price: "₹500 + device cost", description: "Extend coverage to dead zones" },
      { service: "Mesh Network Install", price: "₹1,500 + devices", description: "Seamless whole-home coverage" },
      { service: "Office Network Setup", price: "₹5,000+", description: "Complete office networking solution" },
      { service: "Network Security Audit", price: "₹2,000 - ₹5,000", description: "Security assessment and fixes" },
    ],
    faqs: [
      { question: "Why is my WiFi so slow?", answer: "Slow WiFi can be due to interference, outdated router, wrong placement, or ISP issues. We diagnose and fix the actual cause." },
      { question: "Can you help with WiFi dead zones?", answer: "Yes! We can install WiFi extenders or mesh systems to ensure coverage throughout your home or office." },
      { question: "Do you set up network security?", answer: "Absolutely. We configure firewalls, secure passwords, guest networks, and can set up VPNs for added security." },
    ]
  },
  {
    slug: "hardware-upgrades",
    icon: Wrench,
    title: "Hardware Upgrades",
    shortDescription: "RAM upgrades, SSD installation, graphics card replacement, and custom PC building services.",
    heroDescription: "Upgrade your computer for better performance without buying new. From RAM and SSD upgrades to graphics cards for gaming, we handle all hardware installations professionally.",
    features: [
      "RAM upgrade and installation",
      "SSD upgrade with data migration",
      "Graphics card installation",
      "CPU upgrade and cooling",
      "Power supply upgrade",
      "Custom PC building",
      "Gaming PC upgrades",
      "Workstation upgrades"
    ],
    pricing: [
      { service: "Free Consultation", price: "₹0", description: "Compatibility check and recommendations" },
      { service: "RAM Installation", price: "₹500 + RAM cost", description: "DDR4/DDR5 upgrade with testing" },
      { service: "SSD Installation", price: "₹500 + SSD cost", description: "Includes OS migration and optimization" },
      { service: "Graphics Card Install", price: "₹800 + GPU cost", description: "Driver setup and optimization included" },
      { service: "CPU Upgrade", price: "₹1,000 + CPU cost", description: "Includes thermal paste application" },
      { service: "Custom PC Build", price: "₹2,500 + parts", description: "Complete assembly, cable management, testing" },
    ],
    faqs: [
      { question: "Will upgrading RAM speed up my computer?", answer: "If your computer is low on RAM (4GB or less), upgrading can significantly improve performance, especially for multitasking." },
      { question: "Should I upgrade to SSD?", answer: "Absolutely! An SSD upgrade is the single best upgrade for older computers. Boot times and app loading become 5-10x faster." },
      { question: "Can you check if my PC supports upgrades?", answer: "Yes! Bring your PC for a free compatibility assessment. We'll tell you exactly what can be upgraded and the expected benefits." },
    ]
  },
  {
    slug: "cloud-solutions",
    icon: Cloud,
    title: "Cloud Solutions",
    shortDescription: "Scalable cloud infrastructure, migration services, and managed cloud hosting for businesses of all sizes.",
    heroDescription: "Transform your business with enterprise-grade cloud solutions. We provide seamless cloud migration, infrastructure management, and optimization services powered by AWS, Azure, and Google Cloud.",
    features: [
      "Cloud infrastructure design and setup",
      "AWS, Azure, Google Cloud deployment",
      "Cloud migration and data transfer",
      "Hybrid cloud architecture",
      "Cloud cost optimization",
      "24/7 cloud monitoring",
      "Backup and disaster recovery",
      "Scalable hosting solutions"
    ],
    pricing: [
      { service: "Free Consultation", price: "₹0", description: "Cloud readiness assessment and strategy" },
      { service: "Cloud Migration", price: "₹25,000+", description: "Complete migration to cloud infrastructure" },
      { service: "Managed Cloud", price: "₹10,000/mo", description: "Full management and monitoring" },
      { service: "Cloud Optimization", price: "₹15,000", description: "Cost reduction and performance tuning" },
      { service: "Backup Solutions", price: "₹5,000/mo", description: "Automated backup and recovery" },
      { service: "Hybrid Setup", price: "₹50,000+", description: "On-premise and cloud integration" },
    ],
    faqs: [
      { question: "Which cloud platform is best for my business?", answer: "It depends on your needs. AWS is great for flexibility, Azure integrates well with Microsoft products, and Google Cloud excels in data analytics. We'll recommend the best fit." },
      { question: "How long does cloud migration take?", answer: "Simple migrations take 1-2 weeks, while complex enterprise migrations can take 2-3 months. We ensure zero downtime during the process." },
      { question: "Is cloud storage secure?", answer: "Absolutely. We implement industry-leading security including encryption, access controls, and compliance with GDPR, HIPAA, and other standards." },
    ]
  },
  {
    slug: "cybersecurity",
    icon: Shield,
    title: "Cybersecurity",
    shortDescription: "Comprehensive security audits, threat protection, and 24/7 monitoring to safeguard your digital assets.",
    heroDescription: "Protect your business from cyber threats with our comprehensive security solutions. From vulnerability assessments to incident response, we keep your data and systems secure.",
    features: [
      "Security vulnerability assessments",
      "Penetration testing",
      "Firewall and endpoint protection",
      "24/7 threat monitoring (SOC)",
      "Incident response planning",
      "Security awareness training",
      "Compliance audits (ISO, GDPR, PCI-DSS)",
      "Data loss prevention (DLP)"
    ],
    pricing: [
      { service: "Security Audit", price: "₹15,000", description: "Complete vulnerability assessment" },
      { service: "Penetration Testing", price: "₹30,000+", description: "Ethical hacking and report" },
      { service: "Managed Security", price: "₹20,000/mo", description: "24/7 monitoring and response" },
      { service: "Employee Training", price: "₹10,000", description: "Security awareness program" },
      { service: "Compliance Audit", price: "₹25,000+", description: "GDPR, ISO, PCI-DSS compliance" },
      { service: "Incident Response", price: "₹50,000+", description: "Emergency breach handling" },
    ],
    faqs: [
      { question: "How often should we conduct security audits?", answer: "We recommend quarterly vulnerability scans and annual comprehensive penetration testing. Critical infrastructure may need more frequent assessments." },
      { question: "What happens if we experience a breach?", answer: "Our incident response team acts immediately to contain the threat, investigate the breach, recover systems, and implement preventive measures." },
      { question: "Do you provide compliance certification?", answer: "We help you achieve and maintain compliance with major standards like ISO 27001, GDPR, PCI-DSS, and HIPAA, including documentation and audits." },
    ]
  },
  {
    slug: "custom-development",
    icon: Code,
    title: "Custom Development",
    shortDescription: "Tailored software solutions, web applications, and mobile apps built to meet your unique business needs.",
    heroDescription: "Get custom software that perfectly fits your business processes. From web applications to enterprise systems, we build scalable, maintainable solutions using cutting-edge technologies.",
    features: [
      "Custom web application development",
      "Mobile app development (iOS & Android)",
      "Enterprise software solutions",
      "API development and integration",
      "E-commerce platforms",
      "CRM and ERP systems",
      "Legacy system modernization",
      "Ongoing support and maintenance"
    ],
    pricing: [
      { service: "Free Consultation", price: "₹0", description: "Requirements analysis and proposal" },
      { service: "Website Development", price: "₹50,000+", description: "Custom responsive websites" },
      { service: "Web Application", price: "₹1,50,000+", description: "Full-stack web applications" },
      { service: "Mobile App", price: "₹2,00,000+", description: "iOS and Android apps" },
      { service: "Enterprise Software", price: "₹5,00,000+", description: "Complex business systems" },
      { service: "Maintenance", price: "₹15,000/mo", description: "Updates, support, and hosting" },
    ],
    faqs: [
      { question: "What technologies do you use?", answer: "We use modern tech stacks including React, Node.js, Python, Flutter, React Native, AWS, and more. We choose the best tools for each project." },
      { question: "How long does custom development take?", answer: "A simple website takes 2-4 weeks, web apps take 2-4 months, and enterprise systems can take 6-12 months depending on complexity." },
      { question: "Do you provide source code ownership?", answer: "Yes, you receive full ownership of all source code and intellectual property upon project completion and final payment." },
    ]
  },
  {
    slug: "data-analytics",
    icon: BarChart3,
    title: "Data Analytics",
    shortDescription: "Transform raw data into actionable insights with advanced analytics, visualization, and business intelligence.",
    heroDescription: "Unlock the power of your data with advanced analytics solutions. We help you collect, analyze, and visualize data to make informed business decisions and drive growth.",
    features: [
      "Business intelligence dashboards",
      "Data warehouse design",
      "Predictive analytics",
      "Real-time data processing",
      "Custom reporting solutions",
      "Data visualization (Power BI, Tableau)",
      "ETL pipeline development",
      "Big data solutions"
    ],
    pricing: [
      { service: "Data Assessment", price: "₹10,000", description: "Current data infrastructure review" },
      { service: "BI Dashboard", price: "₹30,000+", description: "Interactive business dashboards" },
      { service: "Data Warehouse", price: "₹75,000+", description: "Centralized data repository" },
      { service: "Analytics Platform", price: "₹1,50,000+", description: "Complete analytics solution" },
      { service: "Predictive Models", price: "₹50,000+", description: "ML-powered predictions" },
      { service: "Managed Analytics", price: "₹25,000/mo", description: "Ongoing analytics support" },
    ],
    faqs: [
      { question: "What data sources can you integrate?", answer: "We can integrate data from virtually any source - databases, APIs, spreadsheets, CRMs, ERPs, social media, IoT devices, and more." },
      { question: "Do we need a lot of data to get started?", answer: "No! We can help you start collecting and organizing data properly. Even small datasets can provide valuable insights when analyzed correctly." },
      { question: "What's the ROI of data analytics?", answer: "Our clients typically see 15-30% improvement in operational efficiency and revenue growth within the first year of implementing analytics solutions." },
    ]
  },
  {
    slug: "ai-automation",
    icon: Bot,
    title: "AI & Automation",
    shortDescription: "Leverage artificial intelligence and automation to streamline operations and enhance productivity.",
    heroDescription: "Embrace the future with AI-powered automation solutions. From chatbots to intelligent process automation, we help you work smarter, reduce costs, and scale efficiently.",
    features: [
      "AI-powered chatbots and virtual assistants",
      "Robotic Process Automation (RPA)",
      "Machine learning model development",
      "Natural language processing (NLP)",
      "Computer vision solutions",
      "Workflow automation",
      "Intelligent document processing",
      "AI-driven customer insights"
    ],
    pricing: [
      { service: "AI Consultation", price: "₹15,000", description: "Use case identification and roadmap" },
      { service: "Chatbot Development", price: "₹40,000+", description: "Custom AI chatbot for your business" },
      { service: "RPA Implementation", price: "₹75,000+", description: "Automate repetitive tasks" },
      { service: "ML Model", price: "₹1,00,000+", description: "Custom machine learning solution" },
      { service: "Process Automation", price: "₹50,000+", description: "End-to-end workflow automation" },
      { service: "AI Support", price: "₹20,000/mo", description: "Monitoring and optimization" },
    ],
    faqs: [
      { question: "What processes can be automated?", answer: "Data entry, report generation, customer service, invoice processing, inventory management, email responses, and many repetitive tasks can be automated." },
      { question: "Will AI replace our employees?", answer: "No, AI augments your team by handling repetitive tasks, allowing employees to focus on strategic, creative work that requires human judgment." },
      { question: "How quickly can we see results from automation?", answer: "Simple automations can be deployed in 2-4 weeks with immediate ROI. Complex AI solutions take 2-3 months but typically deliver 40-60% efficiency gains." },
    ]
  },
];

export const getServiceBySlug = (slug: string): ServiceData | undefined => {
  return servicesData.find(service => service.slug === slug);
};
