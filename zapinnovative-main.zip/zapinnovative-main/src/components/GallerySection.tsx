import { useState } from "react";
import { AnimatedSection, useScrollAnimation } from "@/hooks/useScrollAnimation";

// Import gallery images
import laptopBefore from "@/assets/gallery/laptop-before.jpg";
import laptopAfter from "@/assets/gallery/laptop-after.jpg";
import pcBefore from "@/assets/gallery/pc-before.jpg";
import pcAfter from "@/assets/gallery/pc-after.jpg";
import printerBefore from "@/assets/gallery/printer-before.jpg";
import printerAfter from "@/assets/gallery/printer-after.jpg";

interface RepairCase {
  id: number;
  title: string;
  category: string;
  description: string;
  beforeImage: string;
  afterImage: string;
}

const repairCases: RepairCase[] = [
  {
    id: 1,
    title: "Cracked Laptop Screen",
    category: "Laptop Repair",
    description: "Complete screen replacement for Dell XPS 15 with cracked display",
    beforeImage: laptopBefore,
    afterImage: laptopAfter,
  },
  {
    id: 2,
    title: "Dusty Computer Overheating",
    category: "Computer Repair",
    description: "Deep cleaning and thermal paste replacement for gaming PC",
    beforeImage: pcBefore,
    afterImage: pcAfter,
  },
  {
    id: 3,
    title: "Printer Paper Jam Issue",
    category: "Printer Repair",
    description: "Roller replacement and full service for HP LaserJet printer",
    beforeImage: printerBefore,
    afterImage: printerAfter,
  },
];

const BeforeAfterSlider = ({ beforeImage, afterImage, title }: { 
  beforeImage: string; 
  afterImage: string; 
  title: string;
}) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);

  const handleMove = (clientX: number, rect: DOMRect) => {
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const rect = e.currentTarget.getBoundingClientRect();
    handleMove(e.clientX, rect);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    handleMove(e.touches[0].clientX, rect);
  };

  return (
    <div 
      className="relative w-full aspect-[3/2] rounded-2xl overflow-hidden cursor-ew-resize select-none"
      onMouseMove={handleMouseMove}
      onMouseDown={() => setIsDragging(true)}
      onMouseUp={() => setIsDragging(false)}
      onMouseLeave={() => setIsDragging(false)}
      onTouchMove={handleTouchMove}
      onTouchStart={() => setIsDragging(true)}
      onTouchEnd={() => setIsDragging(false)}
    >
      {/* After Image (Background) */}
      <img 
        src={afterImage} 
        alt={`${title} - After repair`}
        className="absolute inset-0 w-full h-full object-cover"
      />
      
      {/* Before Image (Clipped) */}
      <div 
        className="absolute inset-0 overflow-hidden"
        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
      >
        <img 
          src={beforeImage} 
          alt={`${title} - Before repair`}
          className="absolute inset-0 w-full h-full object-cover"
        />
      </div>

      {/* Slider Line */}
      <div 
        className="absolute top-0 bottom-0 w-1 bg-primary shadow-lg shadow-primary/50"
        style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
      >
        {/* Slider Handle */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-primary border-4 border-background flex items-center justify-center shadow-lg">
          <div className="flex gap-0.5">
            <div className="w-0.5 h-4 bg-background rounded-full" />
            <div className="w-0.5 h-4 bg-background rounded-full" />
          </div>
        </div>
      </div>

      {/* Labels */}
      <div className="absolute top-4 left-4 px-3 py-1.5 rounded-full bg-destructive/90 text-destructive-foreground text-xs font-semibold uppercase tracking-wider">
        Before
      </div>
      <div className="absolute top-4 right-4 px-3 py-1.5 rounded-full bg-primary/90 text-primary-foreground text-xs font-semibold uppercase tracking-wider">
        After
      </div>
    </div>
  );
};

const GallerySection = () => {
  const { ref: gridRef, isVisible: gridVisible } = useScrollAnimation({ threshold: 0.1 });

  return (
    <section id="gallery" className="py-24 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      
      {/* Background Effect */}
      <div className="absolute right-0 top-1/3 w-80 h-80 bg-primary/10 rounded-full blur-[120px]" />
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">
            Our Work
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold mt-4 mb-6">
            Before & After <span className="gradient-text">Gallery</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            See the quality of our repairs firsthand. Drag the slider to compare 
            before and after photos of real customer devices.
          </p>
        </AnimatedSection>

        {/* Gallery Grid */}
        <div 
          ref={gridRef as React.RefObject<HTMLDivElement>}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {repairCases.map((repairCase, index) => (
            <div
              key={repairCase.id}
              className={`group transition-all duration-700 ${
                gridVisible 
                  ? "translate-y-0 opacity-100" 
                  : "translate-y-10 opacity-0"
              }`}
              style={{ transitionDelay: gridVisible ? `${index * 150}ms` : "0ms" }}
            >
              <div className="rounded-2xl overflow-hidden card-gradient border border-border/50 hover:border-primary/30 transition-all duration-300">
                <BeforeAfterSlider 
                  beforeImage={repairCase.beforeImage}
                  afterImage={repairCase.afterImage}
                  title={repairCase.title}
                />
                
                <div className="p-6">
                  <span className="text-primary text-sm font-medium">
                    {repairCase.category}
                  </span>
                  <h3 className="font-display text-lg font-semibold mt-2 mb-2 group-hover:text-primary transition-colors">
                    {repairCase.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {repairCase.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Instruction */}
        <p className="text-center text-muted-foreground text-sm mt-8">
          💡 Tip: Drag the slider left and right to see the before and after comparison
        </p>
      </div>
    </section>
  );
};

export default GallerySection;
