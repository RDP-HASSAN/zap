import { CheckCircle, Zap, Target, Users } from "lucide-react";
import { AnimatedSection, useScrollAnimation } from "@/hooks/useScrollAnimation";

const features = [
  "Certified repair technicians",
  "Same-day service available",
  "Transparent pricing",
  "Genuine replacement parts",
  "2-year repair warranty",
  "Free diagnostic assessment",
];

const AboutSection = () => {
  const { ref: featuresRef, isVisible: featuresVisible } = useScrollAnimation({ threshold: 0.1 });
  const { ref: cardsRef, isVisible: cardsVisible } = useScrollAnimation({ threshold: 0.1 });

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1/2 h-[600px] bg-gradient-to-l from-primary/5 to-transparent" />
      
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div>
            <AnimatedSection animation="fade-left">
              <span className="text-primary font-medium text-sm uppercase tracking-wider">
                Why Choose Us
              </span>
              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold mt-4 mb-6">
                Quality Repairs,{" "}
                <span className="gradient-text">Fair Prices</span>
              </h2>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                At Zapinnovative, we understand how frustrating tech problems can be. That's why 
                our certified technicians work quickly to get your devices back to perfect condition. 
                With years of experience repairing laptops, computers, and printers, we guarantee quality work.
              </p>
            </AnimatedSection>

            {/* Feature List */}
            <div 
              ref={featuresRef as React.RefObject<HTMLDivElement>}
              className="grid sm:grid-cols-2 gap-4"
            >
              {features.map((feature, index) => (
                <div 
                  key={index} 
                  className={`flex items-center gap-3 transition-all duration-500 ${
                    featuresVisible 
                      ? "translate-x-0 opacity-100" 
                      : "-translate-x-4 opacity-0"
                  }`}
                  style={{ transitionDelay: featuresVisible ? `${index * 80}ms` : "0ms" }}
                >
                  <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-foreground">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Content - Feature Cards */}
          <div className="relative">
            <div 
              ref={cardsRef as React.RefObject<HTMLDivElement>}
              className="grid grid-cols-2 gap-4"
            >
              {[
                { icon: Zap, title: "Quick Turnaround", desc: "Most repairs completed within 24-48 hours" },
                { icon: Target, title: "Accurate Diagnosis", desc: "Pinpoint issues with free diagnostic testing" },
                { icon: Users, title: "Expert Technicians", desc: "Certified professionals with years of experience" },
                { icon: CheckCircle, title: "Guaranteed Work", desc: "2-year warranty on all our repairs" },
              ].map((item, index) => (
                <div
                  key={index}
                  className={`p-6 rounded-2xl card-gradient border border-border/50 hover:border-primary/30 transition-all duration-500 ${
                    index % 2 === 1 ? 'translate-y-8' : ''
                  } ${
                    cardsVisible 
                      ? "scale-100 opacity-100" 
                      : "scale-90 opacity-0"
                  }`}
                  style={{ transitionDelay: cardsVisible ? `${index * 100}ms` : "0ms" }}
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <item.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-display font-semibold text-lg mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
              ))}
            </div>

            {/* Floating accent */}
            <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-primary/20 rounded-full blur-[100px]" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
