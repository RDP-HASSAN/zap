import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { AnimatedSection } from "@/hooks/useScrollAnimation";

const faqs = [
  {
    question: "How long does a typical repair take?",
    answer: "Most repairs are completed within 24-48 hours. Simple fixes like screen replacements or RAM upgrades can often be done same-day. We'll give you an accurate estimate after diagnosing your device.",
  },
  {
    question: "Do you offer a warranty on repairs?",
    answer: "Yes! All our repairs come with a 2-year warranty covering both parts and labor. If you experience any issues related to our repair, we'll fix it at no additional cost.",
  },
  {
    question: "Is the diagnostic free?",
    answer: "Absolutely. We provide a free diagnostic for all devices. You'll receive a detailed report of the issues found and a transparent quote before any work begins.",
  },
  {
    question: "Can you recover data from a damaged hard drive?",
    answer: "In most cases, yes. Our data recovery specialists can retrieve data from failed hard drives, SSDs, and even water-damaged devices. We have a high success rate and only charge if we successfully recover your data.",
  },
  {
    question: "Do you repair all laptop and computer brands?",
    answer: "Yes, we repair all major brands including Apple, Dell, HP, Lenovo, Asus, Acer, Microsoft Surface, and custom-built PCs. Our technicians are trained to work with any make or model.",
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept all major credit cards, debit cards, cash, and digital payments including Apple Pay and Google Pay. For business clients, we also offer invoicing options.",
  },
  {
    question: "Do you offer on-site repairs?",
    answer: "Yes, we provide on-site repair services for businesses and homes in the greater Portland area. Contact us to schedule a visit from one of our mobile technicians.",
  },
  {
    question: "What if my device is beyond repair?",
    answer: "If we determine your device cannot be economically repaired, we'll let you know upfront and won't charge for the diagnostic. We can also help you with data transfer to a new device and offer trade-in options.",
  },
];

const FAQSection = () => {
  return (
    <section id="faq" className="py-24 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      
      {/* Background Effect */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-primary/5 rounded-full blur-[120px]" />
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">
            FAQ
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold mt-4 mb-6">
            Frequently Asked Questions
          </h2>
          <p className="text-muted-foreground text-lg">
            Got questions? We've got answers. Find everything you need to know about our repair services.
          </p>
        </AnimatedSection>

        {/* FAQ Accordion */}
        <AnimatedSection animation="fade-up" delay={200} className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card border border-border/50 rounded-xl px-6 data-[state=open]:border-primary/30 transition-colors"
              >
                <AccordionTrigger className="text-left hover:no-underline py-5 text-base font-medium">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </AnimatedSection>
      </div>
    </section>
  );
};

export default FAQSection;
