import { Star, Quote } from "lucide-react";
import { AnimatedSection } from "@/hooks/useScrollAnimation";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";

const testimonials = [
  {
    name: "Rajesh Kumar",
    role: "Small Business Owner",
    content: "My laptop was completely dead and I thought I'd lost everything. Zapinnovative recovered all my data and fixed it in just one day! Incredible service.",
    rating: 5,
  },
  {
    name: "Priya Sharma",
    role: "Freelance Designer",
    content: "They fixed my MacBook screen for half the price of the Apple store. Fast, professional, and they even cleaned the whole laptop. Highly recommended!",
    rating: 5,
  },
  {
    name: "Amit Patel",
    role: "Office Manager",
    content: "Our office printers kept jamming and causing delays. The team at Zapinnovative serviced all 5 printers and now they work like new. Excellent work!",
    rating: 5,
  },
  {
    name: "Sarah Johnson",
    role: "Software Developer",
    content: "Fast turnaround on my desktop repair. They diagnosed the issue within an hour and had it running perfectly the same day. Will definitely use again!",
    rating: 5,
  },
  {
    name: "Michael Chen",
    role: "Photographer",
    content: "Lost years of photos due to a hard drive crash. Zapinnovative recovered everything! Their data recovery service is truly exceptional.",
    rating: 5,
  },
  {
    name: "Lisa Rodriguez",
    role: "Restaurant Owner",
    content: "They set up our entire network and POS system. Super reliable and always available when we need support. Great team!",
    rating: 5,
  },
];

const TestimonialsSection = () => {
  return (
    <section id="testimonials" className="py-24 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      
      {/* Background Effect */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-accent/10 rounded-full blur-[120px]" />
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-primary font-medium text-sm uppercase tracking-wider">
            Testimonials
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold mt-4 mb-6">
            What Our Customers Say
          </h2>
          <p className="text-muted-foreground text-lg">
            Thousands of happy customers trust us with their devices. 
            Here's what some of them have to say.
          </p>
        </AnimatedSection>

        {/* Testimonials Carousel */}
        <AnimatedSection animation="fade-up" delay={200}>
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
            plugins={[
              Autoplay({
                delay: 4000,
                stopOnInteraction: true,
              }),
            ]}
            className="w-full"
          >
            <CarouselContent className="-ml-4">
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={index} className="pl-4 md:basis-1/2 lg:basis-1/3">
                  <div className="relative p-8 rounded-2xl card-gradient border border-border/50 hover:border-primary/30 transition-all duration-300 h-full">
                    {/* Quote Icon */}
                    <Quote className="w-10 h-10 text-primary/20 mb-6" />
                    
                    {/* Rating */}
                    <div className="flex gap-1 mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                      ))}
                    </div>

                    {/* Content */}
                    <p className="text-foreground leading-relaxed mb-6">
                      "{testimonial.content}"
                    </p>

                    {/* Author */}
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                        <span className="font-display font-bold text-primary-foreground">
                          {testimonial.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div>
                        <div className="font-semibold">{testimonial.name}</div>
                        <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                      </div>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <div className="flex justify-center gap-4 mt-8">
              <CarouselPrevious className="static translate-y-0 bg-secondary hover:bg-secondary/80 border-border" />
              <CarouselNext className="static translate-y-0 bg-secondary hover:bg-secondary/80 border-border" />
            </div>
          </Carousel>
        </AnimatedSection>
      </div>
    </section>
  );
};

export default TestimonialsSection;
