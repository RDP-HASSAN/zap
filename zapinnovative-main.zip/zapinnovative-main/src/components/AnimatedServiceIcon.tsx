import { Cloud, Shield, Code, BarChart3, Bot, Laptop, Monitor, Printer, HardDrive, Wifi, Wrench, LucideIcon } from "lucide-react";
import { useEffect, useState } from "react";

interface AnimatedServiceIconProps {
  slug: string;
  className?: string;
}

const AnimatedServiceIcon = ({ slug, className = "" }: AnimatedServiceIconProps) => {
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(prev => !prev);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const renderAnimation = () => {
    switch (slug) {
      case "cloud-solutions":
        return <CloudAnimation isAnimating={isAnimating} />;
      case "cybersecurity":
        return <CybersecurityAnimation isAnimating={isAnimating} />;
      case "custom-development":
        return <DevelopmentAnimation isAnimating={isAnimating} />;
      case "data-analytics":
        return <AnalyticsAnimation isAnimating={isAnimating} />;
      case "ai-automation":
        return <AIAnimation isAnimating={isAnimating} />;
      default:
        return <DefaultAnimation slug={slug} isAnimating={isAnimating} />;
    }
  };

  return (
    <div className={`relative w-full max-w-md mx-auto ${className}`}>
      <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 p-8 overflow-hidden">
        {renderAnimation()}
      </div>
    </div>
  );
};

const CloudAnimation = ({ isAnimating }: { isAnimating: boolean }) => (
  <div className="relative w-full h-full flex items-center justify-center">
    {/* Floating clouds */}
    <div className={`absolute transition-all duration-1000 ${isAnimating ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-60'}`}>
      <div className="relative">
        <Cloud className="w-32 h-32 text-primary" strokeWidth={1.5} />
        {/* Data particles */}
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-all duration-700 ${isAnimating ? 'scale-100' : 'scale-75'}`}>
          <div className="flex gap-1">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className={`w-2 h-2 bg-primary rounded-full transition-all duration-500`}
                style={{ 
                  animationDelay: `${i * 200}ms`,
                  transform: isAnimating ? `translateY(${Math.sin(i * 2) * 10}px)` : 'translateY(0)'
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
    
    {/* Upload/download arrows */}
    <div className="absolute bottom-8 flex gap-8">
      <div className={`transition-all duration-500 ${isAnimating ? 'translate-y-0' : 'translate-y-2'}`}>
        <svg className="w-8 h-8 text-primary/60" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 19V5M5 12l7-7 7 7" />
        </svg>
      </div>
      <div className={`transition-all duration-500 delay-200 ${isAnimating ? 'translate-y-0' : '-translate-y-2'}`}>
        <svg className="w-8 h-8 text-primary/60" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 5v14M5 12l7 7 7-7" />
        </svg>
      </div>
    </div>

    {/* Connection lines */}
    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 200">
      <defs>
        <linearGradient id="cloudGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
          <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.1" />
        </linearGradient>
      </defs>
      <path
        d={isAnimating ? "M40,160 Q100,120 160,160" : "M40,160 Q100,140 160,160"}
        fill="none"
        stroke="url(#cloudGrad)"
        strokeWidth="2"
        className="transition-all duration-1000"
      />
    </svg>
  </div>
);

const CybersecurityAnimation = ({ isAnimating }: { isAnimating: boolean }) => (
  <div className="relative w-full h-full flex items-center justify-center">
    {/* Shield with pulse effect */}
    <div className={`relative transition-all duration-700 ${isAnimating ? 'scale-100' : 'scale-95'}`}>
      <Shield className="w-32 h-32 text-primary" strokeWidth={1.5} />
      
      {/* Scanning line */}
      <div 
        className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent transition-all duration-1000 ${isAnimating ? 'translate-y-32' : 'translate-y-0'}`}
        style={{ opacity: 0.6 }}
      />
      
      {/* Lock icon inside shield */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <svg className={`w-12 h-12 text-primary/80 transition-all duration-500 ${isAnimating ? 'scale-100' : 'scale-90'}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
          <path d="M7 11V7a5 5 0 0110 0v4" />
        </svg>
      </div>
    </div>

    {/* Orbiting security dots */}
    {[0, 1, 2, 3].map((i) => (
      <div
        key={i}
        className="absolute w-3 h-3 bg-primary rounded-full"
        style={{
          top: `${50 + 40 * Math.sin((i * Math.PI / 2) + (isAnimating ? 0.5 : 0))}%`,
          left: `${50 + 40 * Math.cos((i * Math.PI / 2) + (isAnimating ? 0.5 : 0))}%`,
          transform: 'translate(-50%, -50%)',
          opacity: 0.6,
          transition: 'all 1s ease-in-out',
        }}
      />
    ))}

    {/* Threat indicators */}
    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
      {['✓', '✓', '✓'].map((check, i) => (
        <div
          key={i}
          className={`w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center text-green-500 text-xs transition-all duration-300`}
          style={{ transitionDelay: `${i * 100}ms`, opacity: isAnimating ? 1 : 0.5 }}
        >
          {check}
        </div>
      ))}
    </div>
  </div>
);

const DevelopmentAnimation = ({ isAnimating }: { isAnimating: boolean }) => (
  <div className="relative w-full h-full flex items-center justify-center">
    {/* Code brackets */}
    <div className={`relative transition-all duration-700 ${isAnimating ? 'scale-100' : 'scale-95'}`}>
      <Code className="w-28 h-28 text-primary" strokeWidth={1.5} />
    </div>

    {/* Floating code snippets */}
    <div className="absolute inset-0 overflow-hidden">
      {['const', 'function', 'export', '<div>', 'return'].map((code, i) => (
        <div
          key={i}
          className={`absolute text-xs font-mono text-primary/50 transition-all duration-1000`}
          style={{
            top: `${20 + i * 15}%`,
            left: isAnimating ? `${10 + i * 5}%` : `${5 + i * 5}%`,
            opacity: isAnimating ? 0.7 : 0.3,
            transitionDelay: `${i * 100}ms`,
          }}
        >
          {code}
        </div>
      ))}
    </div>

    {/* Terminal cursor */}
    <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-background/50 rounded-lg px-4 py-2 backdrop-blur-sm border border-primary/20">
      <span className="text-primary/60 text-sm font-mono">$</span>
      <span className="text-primary text-sm font-mono">npm run build</span>
      <div className={`w-2 h-4 bg-primary transition-opacity duration-500 ${isAnimating ? 'opacity-100' : 'opacity-0'}`} />
    </div>

    {/* Gear icons */}
    <div className={`absolute top-4 right-4 transition-transform duration-1000 ${isAnimating ? 'rotate-180' : 'rotate-0'}`}>
      <svg className="w-8 h-8 text-primary/40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
      </svg>
    </div>
  </div>
);

const AnalyticsAnimation = ({ isAnimating }: { isAnimating: boolean }) => (
  <div className="relative w-full h-full flex items-center justify-center">
    {/* Chart icon */}
    <div className={`relative transition-all duration-700 ${isAnimating ? 'scale-100' : 'scale-95'}`}>
      <BarChart3 className="w-28 h-28 text-primary" strokeWidth={1.5} />
    </div>

    {/* Animated bar chart */}
    <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-end gap-3 h-24">
      {[60, 80, 45, 90, 70].map((height, i) => (
        <div
          key={i}
          className="w-4 bg-gradient-to-t from-primary to-primary/50 rounded-t transition-all duration-700"
          style={{
            height: isAnimating ? `${height}%` : `${height * 0.5}%`,
            transitionDelay: `${i * 100}ms`,
          }}
        />
      ))}
    </div>

    {/* Data points */}
    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 200">
      <polyline
        points={isAnimating 
          ? "20,140 50,120 80,90 110,110 140,60 170,80" 
          : "20,150 50,140 80,130 110,140 140,120 170,130"
        }
        fill="none"
        stroke="hsl(var(--primary))"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="transition-all duration-1000"
        opacity={0.5}
      />
      {[20, 50, 80, 110, 140, 170].map((x, i) => {
        const y = isAnimating 
          ? [140, 120, 90, 110, 60, 80][i] 
          : [150, 140, 130, 140, 120, 130][i];
        return (
          <circle
            key={i}
            cx={x}
            cy={y}
            r="4"
            fill="hsl(var(--primary))"
            className="transition-all duration-1000"
            style={{ transitionDelay: `${i * 100}ms` }}
          />
        );
      })}
    </svg>

    {/* Percentage indicator */}
    <div className={`absolute top-4 right-4 bg-primary/10 rounded-lg px-3 py-1 transition-all duration-500 ${isAnimating ? 'opacity-100' : 'opacity-50'}`}>
      <span className="text-primary font-bold text-lg">+{isAnimating ? '47' : '23'}%</span>
    </div>
  </div>
);

const AIAnimation = ({ isAnimating }: { isAnimating: boolean }) => (
  <div className="relative w-full h-full flex items-center justify-center">
    {/* Brain/Bot icon */}
    <div className={`relative transition-all duration-700 ${isAnimating ? 'scale-100' : 'scale-95'}`}>
      <Bot className="w-28 h-28 text-primary" strokeWidth={1.5} />
      
      {/* Thinking dots */}
      <div className="absolute -top-4 left-1/2 -translate-x-1/2 flex gap-1">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className={`w-2 h-2 bg-primary rounded-full transition-all duration-300`}
            style={{
              transform: isAnimating ? `translateY(${Math.sin((Date.now() / 300) + i) * 5}px)` : 'translateY(0)',
              opacity: isAnimating ? 1 : 0.5,
              animationDelay: `${i * 200}ms`,
            }}
          />
        ))}
      </div>
    </div>

    {/* Neural network connections */}
    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 200">
      <defs>
        <linearGradient id="aiGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.5" />
          <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.1" />
        </linearGradient>
      </defs>
      {/* Connection lines */}
      {[
        { x1: 30, y1: 50, x2: 100, y2: 100 },
        { x1: 30, y1: 150, x2: 100, y2: 100 },
        { x1: 170, y1: 50, x2: 100, y2: 100 },
        { x1: 170, y1: 150, x2: 100, y2: 100 },
      ].map((line, i) => (
        <line
          key={i}
          x1={line.x1}
          y1={line.y1}
          x2={line.x2}
          y2={line.y2}
          stroke="url(#aiGrad)"
          strokeWidth={isAnimating ? 2 : 1}
          className="transition-all duration-500"
          style={{ transitionDelay: `${i * 100}ms` }}
        />
      ))}
      {/* Nodes */}
      {[
        { x: 30, y: 50 },
        { x: 30, y: 150 },
        { x: 170, y: 50 },
        { x: 170, y: 150 },
      ].map((node, i) => (
        <circle
          key={i}
          cx={node.x}
          cy={node.y}
          r={isAnimating ? 6 : 4}
          fill="hsl(var(--primary))"
          opacity={0.6}
          className="transition-all duration-500"
          style={{ transitionDelay: `${i * 100}ms` }}
        />
      ))}
    </svg>

    {/* Processing indicator */}
    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-background/50 rounded-full px-4 py-2 backdrop-blur-sm border border-primary/20">
      <div className={`w-2 h-2 rounded-full bg-green-500 ${isAnimating ? 'animate-pulse' : ''}`} />
      <span className="text-xs text-muted-foreground">Processing...</span>
    </div>
  </div>
);

const DefaultAnimation = ({ slug, isAnimating }: { slug: string; isAnimating: boolean }) => {
  const iconMap: Record<string, LucideIcon> = {
    "laptop-repair": Laptop,
    "computer-repair": Monitor,
    "printer-repair": Printer,
    "data-recovery": HardDrive,
    "network-setup": Wifi,
    "hardware-upgrades": Wrench,
  };

  const Icon = iconMap[slug] || Laptop;

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <div className={`transition-all duration-700 ${isAnimating ? 'scale-100 rotate-0' : 'scale-95 rotate-3'}`}>
        <Icon className="w-32 h-32 text-primary" strokeWidth={1.5} />
      </div>
      
      {/* Decorative circles */}
      <div className={`absolute w-48 h-48 border border-primary/20 rounded-full transition-all duration-1000 ${isAnimating ? 'scale-100 opacity-100' : 'scale-90 opacity-50'}`} />
      <div className={`absolute w-64 h-64 border border-primary/10 rounded-full transition-all duration-1000 delay-200 ${isAnimating ? 'scale-100 opacity-100' : 'scale-95 opacity-30'}`} />
      
      {/* Floating particles */}
      {[...Array(6)].map((_, i) => (
        <div
          key={i}
          className="absolute w-2 h-2 bg-primary/40 rounded-full transition-all duration-1000"
          style={{
            top: `${20 + (i * 12)}%`,
            left: `${15 + (i * 12)}%`,
            transform: isAnimating ? `translateY(${Math.sin(i) * 10}px)` : 'translateY(0)',
            transitionDelay: `${i * 150}ms`,
          }}
        />
      ))}
    </div>
  );
};

export default AnimatedServiceIcon;
